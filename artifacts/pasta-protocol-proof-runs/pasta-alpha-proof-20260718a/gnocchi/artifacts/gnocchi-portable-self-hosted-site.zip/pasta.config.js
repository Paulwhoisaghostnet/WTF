window.PASTA_SITE_CONFIG = {
  "app": "gnocchi",
  "label": "Gnocchi",
  "title": "Gnocchi portable Shadownet proof · pasta-alpha-proof-20260718a",
  "description": "Exported from the actual Gnocchi Studio and served from the extracted standalone ZIP without Objkt, Teia, or wtfOS.",
  "contract": "KT1NJJ55w4TLkRVfuweeRfvT9jvWFf4viaup",
  "tokenId": 0,
  "network": "shadownet"
};
