window.PASTA_SITE_CONFIG = {
  "app": "spaghetti",
  "label": "Spaghetti",
  "title": "Spaghetti portable Shadownet proof · pasta-alpha-proof-20260718a",
  "description": "Exported from the actual Spaghetti Studio and served from the extracted standalone ZIP without Objkt, Teia, or wtfOS.",
  "contract": "KT1CxnMv3RYwAGPYB4dgdn3QDP6J6LWGyPi1",
  "tokenId": 0,
  "network": "shadownet"
};
