window.PASTA_SITE_CONFIG = {
  "app": "rotini",
  "label": "Rotini",
  "title": "Rotini portable Shadownet proof · pasta-alpha-proof-20260718a",
  "description": "Exported from the actual Rotini Studio and served from the extracted standalone ZIP without Objkt, Teia, or wtfOS.",
  "contract": "KT1LUc15yfskvtWfKvYt9oFgXt24TnWx1P8T",
  "tokenId": 0,
  "network": "shadownet"
};
