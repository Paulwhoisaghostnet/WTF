import React, { useRef, useMemo, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Sky, Stars } from '@react-three/drei';
import * as THREE from 'three';
import { createNoise3D, createNoise2D } from 'simplex-noise';

const noise3D = createNoise3D();
const noise2D = createNoise2D();

// Global simulation state
export const simState = {
  time: 0,
  wind: new THREE.Vector2(1, 0.5).normalize(),
  current: new THREE.Vector2(0.5, -0.2).normalize(),
  windOffset: new THREE.Vector2(0, 0),
  currentOffset: new THREE.Vector2(0, 0),
  tide: 0,
  weatherType: 'clear', // 'clear', 'rain', 'fog', 'storm'
  weatherIntensity: 0,
  lightning: 0,
  player: {
    health: 100,
    temp: 37, // Celsius
    hydration: 100,
  },
  cameraMode: 'survivor', // 'survivor', 'bird', 'fish', 'raft'
  bird: { pos: new THREE.Vector3(0, 30, 0), speed: 0, yaw: 0, pitch: 0, roll: 0 },
  fish: { pos: new THREE.Vector3(0, -5, 0), yaw: 0, pitch: 0, speed: 0 },
  survivor: { pos: new THREE.Vector3(0, 2, 0), yaw: 0 },
  raftControls: { rudder: 0, sailAngle: 0, sailDeployed: 1 },
  raftVelocity: new THREE.Vector3(0, 0, 0),
  cameraAngle: { yaw: 0, pitch: 0 },
};

export function getWaterHeight(x: number, z: number, time: number) {
  let y = 0;
  // Base swell (currents)
  y += noise3D(x * 0.02 + simState.currentOffset.x, z * 0.02 + simState.currentOffset.y, time * 0.1) * 2.5;
  // Wind waves
  y += noise3D(x * 0.05 + simState.windOffset.x, z * 0.05 + simState.windOffset.y, time * 0.3) * (1.0 + simState.weatherIntensity * 2.0);
  // Choppiness
  y += noise3D(x * 0.15 - time * 0.2, z * 0.15 + time * 0.2, time * 0.5) * (0.3 + simState.weatherIntensity * 0.5);
  // Tide
  y += simState.tide;
  return y;
}

export function getOceanFloorHeight(x: number, z: number) {
  let y = -50; // Base depth
  
  // Large scale features (continents/islands)
  let islandNoise = noise2D(x * 0.0005, z * 0.0005);
  // Make islands sparse
  if (islandNoise > 0.6) {
    y += (islandNoise - 0.6) * 300; // Peak height
  }
  
  y += noise2D(x * 0.002, z * 0.002) * 20; // Mountains/Trenches
  y += noise2D(x * 0.01, z * 0.01) * 5;
  return y;
}

const Ocean = React.forwardRef<THREE.Group>((props, ref) => {
  const geomInner = useMemo(() => {
    const g = new THREE.PlaneGeometry(150, 150, 256, 256);
    g.rotateX(-Math.PI / 2);
    return g;
  }, []);
  
  const geomOuter = useMemo(() => {
    const g = new THREE.PlaneGeometry(2000, 2000, 128, 128);
    g.rotateX(-Math.PI / 2);
    return g;
  }, []);

  const innerRef = useRef<THREE.Mesh>(null);
  const outerRef = useRef<THREE.Mesh>(null);
  const groupRef = useRef<THREE.Group>(null);
  
  React.useImperativeHandle(ref, () => groupRef.current as THREE.Group);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    const camPos = state.camera.position;
    
    if (innerRef.current) {
      const gridSize = 150 / 256;
      const snappedX = Math.floor(camPos.x / gridSize) * gridSize;
      const snappedZ = Math.floor(camPos.z / gridSize) * gridSize;
      innerRef.current.position.set(snappedX, 0, snappedZ);
      
      const posAttribute = geomInner.attributes.position;
      for (let i = 0; i < posAttribute.count; i++) {
        const x = posAttribute.getX(i) + snappedX;
        const z = posAttribute.getZ(i) + snappedZ;
        posAttribute.setY(i, getWaterHeight(x, z, time));
      }
      posAttribute.needsUpdate = true;
      geomInner.computeVertexNormals();
    }
    
    if (outerRef.current) {
      const gridSize = 2000 / 128;
      const snappedX = Math.floor(camPos.x / gridSize) * gridSize;
      const snappedZ = Math.floor(camPos.z / gridSize) * gridSize;
      outerRef.current.position.set(snappedX, -0.1, snappedZ);
      
      const posAttribute = geomOuter.attributes.position;
      for (let i = 0; i < posAttribute.count; i++) {
        const x = posAttribute.getX(i) + snappedX;
        const z = posAttribute.getZ(i) + snappedZ;
        posAttribute.setY(i, getWaterHeight(x, z, time));
      }
      posAttribute.needsUpdate = true;
      geomOuter.computeVertexNormals();
    }
  });

  const material = useMemo(() => new THREE.MeshPhysicalMaterial({
    color: "#1ca3ec",
    emissive: "#001e2f",
    roughness: 0.2,
    metalness: 0.8,
    transparent: true,
    opacity: 0.9,
    side: THREE.DoubleSide
  }), []);

  return (
    <group ref={groupRef}>
      <mesh ref={innerRef} geometry={geomInner} material={material} receiveShadow />
      <mesh ref={outerRef} geometry={geomOuter} material={material} receiveShadow />
    </group>
  );
});

function OceanFloor() {
  const geom = useMemo(() => {
    const g = new THREE.PlaneGeometry(2000, 2000, 128, 128);
    g.rotateX(-Math.PI / 2);
    return g;
  }, []);

  const meshRef = useRef<THREE.Mesh>(null);
  const lastSnapped = useRef({ x: Infinity, z: Infinity });

  const material = useMemo(() => {
    const mat = new THREE.MeshStandardMaterial({ color: "#0a2a3f", roughness: 0.9 });
    mat.onBeforeCompile = (shader) => {
      shader.uniforms.time = { value: 0 };
      mat.userData.shader = shader;
      
      shader.vertexShader = `
        varying vec3 vWorldPos;
        ${shader.vertexShader}
      `.replace(
        `#include <worldpos_vertex>`,
        `
        #include <worldpos_vertex>
        vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        `
      );
      
      shader.fragmentShader = `
        uniform float time;
        varying vec3 vWorldPos;
        
        // Simple 2D noise for caustics
        vec2 hash( vec2 p ) {
          p = vec2( dot(p,vec2(127.1,311.7)), dot(p,vec2(269.5,183.3)) );
          return -1.0 + 2.0*fract(sin(p)*43758.5453123);
        }
        float noise( in vec2 p ) {
          const float K1 = 0.366025404; // (sqrt(3)-1)/2;
          const float K2 = 0.211324865; // (3-sqrt(3))/6;
          vec2  i = floor( p + (p.x+p.y)*K1 );
          vec2  a = p - i + (i.x+i.y)*K2;
          float m = step(a.y,a.x); 
          vec2  o = vec2(m,1.0-m);
          vec2  b = a - o + K2;
          vec2  c = a - 1.0 + 2.0*K2;
          vec3  h = max( 0.5-vec3(dot(a,a), dot(b,b), dot(c,c) ), 0.0 );
          vec3  n = h*h*h*h*vec3( dot(a,hash(i+0.0)), dot(b,hash(i+o)), dot(c,hash(i+1.0)));
          return dot( n, vec3(70.0) );
        }

        ${shader.fragmentShader}
      `.replace(
        `#include <color_fragment>`,
        `
        #include <color_fragment>
        
        float n1 = noise(vWorldPos.xz * 0.2 + time * 0.5);
        float n2 = noise(vWorldPos.xz * 0.4 - time * 0.3);
        float caustic = max(0.0, sin(n1 * 5.0) * cos(n2 * 5.0));
        caustic = pow(caustic, 3.0) * 1.5; // sharpen
        
        // Fade caustics with depth
        float depthFade = clamp(1.0 - (abs(vWorldPos.y) / 50.0), 0.0, 1.0);
        
        diffuseColor.rgb += vec3(0.2, 0.8, 1.0) * caustic * depthFade;
        `
      );
    };
    return mat;
  }, []);

  useFrame((state) => {
    if (material.userData.shader) {
      material.userData.shader.uniforms.time.value = state.clock.getElapsedTime();
    }
    if (meshRef.current) {
      const camPos = state.camera.position;
      const gridSize = 2000 / 128;
      const snappedX = Math.floor(camPos.x / gridSize) * gridSize;
      const snappedZ = Math.floor(camPos.z / gridSize) * gridSize;
      
      if (snappedX !== lastSnapped.current.x || snappedZ !== lastSnapped.current.z) {
        meshRef.current.position.set(snappedX, -10, snappedZ);
        
        const posAttribute = geom.attributes.position;
        for (let i = 0; i < posAttribute.count; i++) {
          const x = posAttribute.getX(i);
          const z = posAttribute.getZ(i);
          const worldX = x + snappedX;
          const worldZ = z + snappedZ;
          
          const y = getOceanFloorHeight(worldX, worldZ);
          posAttribute.setY(i, y);
        }
        posAttribute.needsUpdate = true;
        geom.computeVertexNormals();
        
        lastSnapped.current = { x: snappedX, z: snappedZ };
      }
    }
  });

  return (
    <mesh ref={meshRef} geometry={geom} material={material} receiveShadow />
  );
}

function Raft({ raftRef }: { raftRef: React.RefObject<THREE.Group | null> }) {
  const velocity = useRef(new THREE.Vector3());
  const logsRef = useRef<THREE.Group>(null);
  const logVels = useRef([0, 0, 0, 0, 0, 0]);
  const logXs = [-0.75, -0.45, -0.15, 0.15, 0.45, 0.75];
  
  useFrame((state, delta) => {
    if (!raftRef.current) return;
    
    const dt = Math.min(delta, 0.033); // Clamp delta to ensure physics stability (min 30fps equivalent)
    const time = state.clock.getElapsedTime();
    const pos = raftRef.current.position;
    
    const waterY = getWaterHeight(pos.x, pos.z, time);
    const floorY = getOceanFloorHeight(pos.x, pos.z);
    const surfaceY = Math.max(waterY, floorY);
    
    // Buoyancy for the main raft group
    const buoyancy = (surfaceY - pos.y) * 10.0;
    velocity.current.y += buoyancy * dt;
    velocity.current.y *= 0.9; 
    pos.y += velocity.current.y * dt;
    
    // Normal calculation for rotation
    const deltaXZ = 0.5;
    const getSurfaceHeight = (x: number, z: number) => Math.max(getWaterHeight(x, z, time), getOceanFloorHeight(x, z));
    
    const hL = getSurfaceHeight(pos.x - deltaXZ, pos.z);
    const hR = getSurfaceHeight(pos.x + deltaXZ, pos.z);
    const hD = getSurfaceHeight(pos.x, pos.z - deltaXZ);
    const hU = getSurfaceHeight(pos.x, pos.z + deltaXZ);
    
    const normal = new THREE.Vector3(hL - hR, deltaXZ * 2, hD - hU).normalize();
    
    const targetQuaternion = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
    raftRef.current.quaternion.slerp(targetQuaternion, dt * 5);
    
    // Individual Log Physics
    if (logsRef.current) {
      logsRef.current.children.forEach((log, i) => {
        if (i >= 6) return; // Only process the 6 logs
        const worldX = pos.x + logXs[i];
        const logWaterY = getSurfaceHeight(worldX, pos.z);
        // Calculate local target Y relative to the main raft group
        const targetLocalY = logWaterY - pos.y;
        
        // Stable lerp instead of spring physics to prevent glitching
        log.position.y = THREE.MathUtils.lerp(log.position.y, targetLocalY, dt * 5.0);
      });
    }
    
    // Drift & Navigation
    let driftX = simState.current.x * 1.5 + simState.wind.x * 0.5;
    let driftZ = simState.current.y * 1.5 + simState.wind.y * 0.5;
    
    // Apply Sail Force
    if (simState.raftControls.sailDeployed > 0) {
      const sailDir = new THREE.Vector3(Math.sin(simState.raftControls.sailAngle), 0, Math.cos(simState.raftControls.sailAngle));
      const windForce = simState.wind.dot(new THREE.Vector2(sailDir.x, sailDir.z));
      if (windForce > 0) {
        driftX += sailDir.x * windForce * simState.raftControls.sailDeployed * 5.0;
        driftZ += sailDir.z * windForce * simState.raftControls.sailDeployed * 5.0;
      }
    }
    
    // Apply Rudder Rotation
    const speed = Math.sqrt(driftX * driftX + driftZ * driftZ);
    if (speed > 0.1) {
      raftRef.current.rotateY(simState.raftControls.rudder * speed * dt * 0.5);
    }
    
    // Repel from islands
    const floorHL = getOceanFloorHeight(pos.x - 5, pos.z);
    const floorHR = getOceanFloorHeight(pos.x + 5, pos.z);
    const floorHD = getOceanFloorHeight(pos.x, pos.z - 5);
    const floorHU = getOceanFloorHeight(pos.x, pos.z + 5);
    const gradX = floorHR - floorHL;
    const gradZ = floorHU - floorHD;
    
    if (floorY > -20) {
       const repelStrength = Math.max(0, (floorY + 20) * 0.5);
       driftX -= gradX * repelStrength;
       driftZ -= gradZ * repelStrength;
    }
    
    // Move raft in the direction it's facing (if sail is pushing it)
    const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(raftRef.current.quaternion);
    const moveSpeed = driftX * forward.x + driftZ * forward.z;
    const moveVec = forward.multiplyScalar(moveSpeed * dt);
    pos.add(moveVec);
    
    // Store velocity for survivor to follow
    simState.raftVelocity.copy(moveVec).divideScalar(dt);
  });

  return (
    <group ref={raftRef} castShadow>
      {/* Logs Group */}
      <group ref={logsRef}>
        {logXs.map((x, i) => (
          <mesh key={i} position={[x, 0, (i % 2 === 0 ? 0.1 : -0.1)]} rotation={[Math.PI / 2, 0, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.12 + Math.random() * 0.03, 0.12 + Math.random() * 0.03, 2.6 + Math.random() * 0.2, 8]} />
            <meshStandardMaterial color={i % 2 === 0 ? "#4a332a" : "#5c4033"} roughness={0.9} />
          </mesh>
        ))}
      </group>
      
      {/* Cross beams */}
      {[-0.9, 0, 0.9].map((z, i) => (
        <mesh key={`cross-${i}`} position={[0, 0.12, z]} rotation={[0, 0, Math.PI / 2]} castShadow receiveShadow>
          <cylinderGeometry args={[0.08, 0.08, 1.8, 8]} />
          <meshStandardMaterial color="#3a231a" roughness={0.9} />
        </mesh>
      ))}
      
      {/* Ropes binding the logs */}
      {[-0.9, 0, 0.9].map((z, i) => (
        <group key={`rope-${i}`} position={[0, 0.12, z]}>
          {logXs.map((x, j) => (
            <mesh key={`r-${j}`} position={[x, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.13, 0.02, 8, 16]} />
              <meshStandardMaterial color="#d4c4a8" roughness={1} />
            </mesh>
          ))}
        </group>
      ))}
      
      {/* Mast */}
      <mesh position={[0, 1.4, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[0.06, 0.08, 2.8, 8]} />
        <meshStandardMaterial color="#4a332a" roughness={0.9} />
      </mesh>
      
      {/* Sail Group attached to Mast */}
      <group position={[0, 1.4, 0]} rotation={[0, simState.raftControls.sailAngle, 0]}>
        {/* Sail Yard */}
        <mesh position={[0, 0.8, 0]} rotation={[0, 0, Math.PI / 2]} castShadow receiveShadow>
          <cylinderGeometry args={[0.04, 0.04, 1.4, 8]} />
          <meshStandardMaterial color="#3a231a" roughness={0.9} />
        </mesh>
        {/* Sail (Curved) */}
        <mesh position={[0, 0.1, 0.05]} scale={[1, simState.raftControls.sailDeployed, 1]} castShadow>
          <planeGeometry args={[1.2, 1.4]} />
          <meshStandardMaterial color="#dcd5c9" roughness={0.9} side={THREE.DoubleSide} />
        </mesh>
      </group>
      
      {/* Rudder */}
      <group position={[0, 0.2, 1.2]} rotation={[0, simState.raftControls.rudder, 0]}>
        <mesh position={[0, -0.4, 0.2]}>
          <boxGeometry args={[0.05, 0.8, 0.4]} />
          <meshStandardMaterial color="#3a231a" />
        </mesh>
        <mesh position={[0, 0.2, 0.4]} rotation={[Math.PI/2, 0, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 0.8]} />
          <meshStandardMaterial color="#4a332a" />
        </mesh>
      </group>
      {/* Supplies: Crate */}
      <mesh position={[-0.4, 0.25, 0.8]} rotation={[0, Math.PI / 6, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.4, 0.4, 0.4]} />
        <meshStandardMaterial color="#6b4423" roughness={0.8} />
      </mesh>
      {/* Supplies: Barrel */}
      <mesh position={[0.4, 0.3, 0.7]} castShadow receiveShadow>
        <cylinderGeometry args={[0.2, 0.2, 0.5, 12]} />
        <meshStandardMaterial color="#3e2723" roughness={0.7} />
      </mesh>
    </group>
  );
}

function CameraController({ raftRef }: { raftRef: React.RefObject<THREE.Group | null> }) {
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const [keys, setKeys] = useState({ w: false, a: false, s: false, d: false, q: false, e: false });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMouse({
        x: (e.clientX / window.innerWidth) * 2 - 1,
        y: -(e.clientY / window.innerHeight) * 2 + 1
      });
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (['w','a','s','d','q','e'].includes(key)) setKeys(k => ({...k, [key]: true}));
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (['w','a','s','d','q','e'].includes(key)) setKeys(k => ({...k, [key]: false}));
    };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useFrame((state, delta) => {
    if (!raftRef.current) return;
    const raftPos = raftRef.current.position;
    const dt = Math.min(delta, 0.033);
    
    let targetCamPos = new THREE.Vector3();
    let lookAtPos = new THREE.Vector3();
    
    if (simState.cameraMode === 'raft') {
      // Raft POV: Fixed at mast, controls rudder and sail
      if (keys.a) simState.raftControls.rudder = Math.min(Math.PI/4, simState.raftControls.rudder + dt);
      if (keys.d) simState.raftControls.rudder = Math.max(-Math.PI/4, simState.raftControls.rudder - dt);
      if (!keys.a && !keys.d) simState.raftControls.rudder *= 0.9; // auto-center
      
      if (keys.w) simState.raftControls.sailDeployed = Math.min(1, simState.raftControls.sailDeployed + dt);
      if (keys.s) simState.raftControls.sailDeployed = Math.max(0, simState.raftControls.sailDeployed - dt);
      
      if (keys.q) simState.raftControls.sailAngle = Math.max(-Math.PI/2, simState.raftControls.sailAngle - dt);
      if (keys.e) simState.raftControls.sailAngle = Math.min(Math.PI/2, simState.raftControls.sailAngle + dt);

      const localOffset = new THREE.Vector3(0, 1.5, 0.2); // Middle of mast looking forward
      targetCamPos = localOffset.applyMatrix4(raftRef.current.matrixWorld);
      
      const totalYaw = -mouse.x * Math.PI;
      const totalPitch = mouse.y * Math.PI / 2;
      
      const lookDir = new THREE.Vector3(
        Math.sin(totalYaw) * Math.cos(totalPitch),
        Math.sin(totalPitch),
        Math.cos(totalYaw) * Math.cos(totalPitch)
      );
      // Apply raft rotation to look dir
      lookDir.applyQuaternion(raftRef.current.quaternion);
      lookAtPos = targetCamPos.clone().add(lookDir.multiplyScalar(5));
      
    } else if (simState.cameraMode === 'survivor') {
      // Survivor POV: Invisible survivor moving in world space
      if (keys.a) simState.survivor.yaw += dt * 2;
      if (keys.d) simState.survivor.yaw -= dt * 2;
      
      const moveSpeed = 5;
      const forward = new THREE.Vector3(Math.sin(simState.survivor.yaw), 0, Math.cos(simState.survivor.yaw));
      if (keys.w) simState.survivor.pos.add(forward.clone().multiplyScalar(moveSpeed * dt));
      if (keys.s) simState.survivor.pos.add(forward.clone().multiplyScalar(-moveSpeed * dt));
      
      // Check if on raft
      const distToRaft = simState.survivor.pos.distanceTo(raftPos);
      const onRaft = distToRaft < 3.0;
      
      if (onRaft) {
        // Add raft velocity so survivor stays on the raft
        simState.survivor.pos.addScaledVector(simState.raftVelocity, dt);
      }
      
      // Collision with water/floor
      const waterY = getWaterHeight(simState.survivor.pos.x, simState.survivor.pos.z, state.clock.elapsedTime);
      const floorY = getOceanFloorHeight(simState.survivor.pos.x, simState.survivor.pos.z);
      
      let surfaceY = Math.max(waterY, floorY);
      if (onRaft) surfaceY = Math.max(surfaceY, raftPos.y + 0.2);
      
      simState.survivor.pos.y = surfaceY + 1.8; // 1.8m tall
      
      targetCamPos = simState.survivor.pos.clone();
      
      const totalPitch = mouse.y * Math.PI / 2;
      const lookDir = new THREE.Vector3(
        Math.sin(simState.survivor.yaw) * Math.cos(totalPitch),
        Math.sin(totalPitch),
        Math.cos(simState.survivor.yaw) * Math.cos(totalPitch)
      );
      lookAtPos = targetCamPos.clone().add(lookDir.multiplyScalar(5));
      
    } else if (simState.cameraMode === 'bird') {
      // Bird POV: Flight dynamics
      if (keys.w) simState.bird.speed = Math.min(20, simState.bird.speed + dt * 10);
      if (keys.s) simState.bird.speed = Math.max(0, simState.bird.speed - dt * 20);
      
      if (keys.a) simState.bird.roll = Math.min(Math.PI/4, simState.bird.roll + dt * 2);
      if (keys.d) simState.bird.roll = Math.max(-Math.PI/4, simState.bird.roll - dt * 2);
      if (!keys.a && !keys.d) simState.bird.roll *= 0.9;
      
      simState.bird.yaw -= simState.bird.roll * dt;
      
      // Mouse aim when hovering (speed < 2)
      if (simState.bird.speed < 2) {
        simState.bird.yaw -= mouse.x * dt * 2;
        simState.bird.pitch = mouse.y * Math.PI / 2;
      } else {
        simState.bird.pitch *= 0.95; // auto level when flying
      }
      
      const forward = new THREE.Vector3(
        Math.sin(simState.bird.yaw) * Math.cos(simState.bird.pitch),
        Math.sin(simState.bird.pitch),
        Math.cos(simState.bird.yaw) * Math.cos(simState.bird.pitch)
      );
      
      simState.bird.pos.add(forward.clone().multiplyScalar(simState.bird.speed * dt));
      
      // Collision
      const waterY = getWaterHeight(simState.bird.pos.x, simState.bird.pos.z, state.clock.elapsedTime);
      const floorY = getOceanFloorHeight(simState.bird.pos.x, simState.bird.pos.z);
      simState.bird.pos.y = Math.max(simState.bird.pos.y, Math.max(waterY, floorY) + 1);
      
      targetCamPos = simState.bird.pos.clone();
      lookAtPos = targetCamPos.clone().add(forward.multiplyScalar(5));
      
      // Apply roll to camera
      state.camera.rotation.z = simState.bird.roll;
      
    } else if (simState.cameraMode === 'fish') {
      // Fish POV
      if (keys.w) simState.fish.speed = Math.min(10, simState.fish.speed + dt * 5);
      if (keys.s) simState.fish.speed = Math.max(0, simState.fish.speed - dt * 5);
      if (!keys.w && !keys.s) simState.fish.speed *= 0.95;
      
      simState.fish.yaw -= mouse.x * dt * 2;
      simState.fish.pitch = mouse.y * Math.PI / 2;
      
      const forward = new THREE.Vector3(
        Math.sin(simState.fish.yaw) * Math.cos(simState.fish.pitch),
        Math.sin(simState.fish.pitch),
        Math.cos(simState.fish.yaw) * Math.cos(simState.fish.pitch)
      );
      
      simState.fish.pos.add(forward.clone().multiplyScalar(simState.fish.speed * dt));
      
      // Collision
      const waterY = getWaterHeight(simState.fish.pos.x, simState.fish.pos.z, state.clock.elapsedTime);
      const floorY = getOceanFloorHeight(simState.fish.pos.x, simState.fish.pos.z);
      simState.fish.pos.y = Math.max(floorY + 0.5, Math.min(waterY - 0.5, simState.fish.pos.y));
      
      targetCamPos = simState.fish.pos.clone();
      lookAtPos = targetCamPos.clone().add(forward.multiplyScalar(5));
    }
    
    if (simState.cameraMode !== 'bird') {
      state.camera.rotation.z = 0; // Reset roll for non-bird modes
    }
    
    state.camera.position.lerp(targetCamPos, dt * 10);
    
    const currentLookAt = new THREE.Vector3(0,0,-1).applyQuaternion(state.camera.quaternion).add(state.camera.position);
    currentLookAt.lerp(lookAtPos, dt * 10);
    state.camera.lookAt(currentLookAt);
  });
  return null;
}

function Environment() {
  const sunRef = useRef<THREE.DirectionalLight>(null);
  const skyRef = useRef<any>(null);
  const lightningRef = useRef<THREE.PointLight>(null);
  const underwaterLightRef = useRef<THREE.DirectionalLight>(null);
  
  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    const dayDuration = 3600; // 1 hour
    const timeOffset = (8 / 24) * dayDuration; // Start at 8 AM
    const dayCycle = ((time + timeOffset) / dayDuration) * Math.PI * 2;
    
    const sunX = Math.cos(dayCycle) * 100;
    const sunY = Math.sin(dayCycle) * 100 + 50; // Shift up for 16h day, 8h night
    const sunZ = Math.sin(dayCycle * 0.5) * 50;
    
    const sunPos = new THREE.Vector3(sunX, sunY, sunZ);
    const sunHeight = Math.max(0, sunY / 150);
    
    if (sunRef.current) {
      sunRef.current.position.copy(sunPos);
      sunRef.current.intensity = sunHeight * 2 * (1 - simState.weatherIntensity * 0.8);
    }
    
    if (underwaterLightRef.current) {
      // Light moves slightly based on waves to simulate refraction
      const waveShiftX = Math.sin(time * 2.0) * 5;
      const waveShiftZ = Math.cos(time * 1.5) * 5;
      underwaterLightRef.current.position.set(sunX + waveShiftX, sunY, sunZ + waveShiftZ);
      underwaterLightRef.current.intensity = sunHeight * 1.5 * (1 - simState.weatherIntensity * 0.8);
    }
    
    if (skyRef.current) {
      skyRef.current.material.uniforms.sunPosition.value.copy(sunPos);
    }
    
    const dayFog = new THREE.Color('#87CEEB');
    const nightFog = new THREE.Color('#020813');
    const sunsetFog = new THREE.Color('#ff7e40');
    const stormFog = new THREE.Color('#222222');
    const denseFog = new THREE.Color('#aaaaaa');
    
    let fogColor = new THREE.Color();
    if (sunHeight > 0.2) {
      fogColor.lerpColors(sunsetFog, dayFog, (sunHeight - 0.2) / 0.8);
    } else if (sunHeight > 0) {
      fogColor.lerpColors(nightFog, sunsetFog, sunHeight / 0.2);
    } else {
      fogColor.copy(nightFog);
    }
    
    if (simState.weatherType === 'storm' || simState.weatherType === 'rain') {
      fogColor.lerp(stormFog, simState.weatherIntensity);
    } else if (simState.weatherType === 'fog') {
      fogColor.lerp(denseFog, simState.weatherIntensity);
    }
    
    if (state.scene.fog) {
      const fog = state.scene.fog as THREE.Fog;
      
      let targetFar = 150;
      let targetNear = 10;
      
      if (simState.weatherType === 'fog') {
        targetFar = 40;
      } else if (simState.weatherType === 'storm') {
        targetFar = 80;
      }
      
      if (simState.cameraMode === 'bird') {
        targetFar *= 1.5;
        targetNear = 25;
      } else if (simState.cameraMode === 'fish') {
        targetFar = 300; // Greatly improved underwater visibility
        targetNear = 1;
        fogColor.copy(new THREE.Color('#0a3a5a')); // Clearer blue, less affected by weather
      }
      
      fog.color.lerp(fogColor, 0.1);
      fog.far = THREE.MathUtils.lerp(fog.far, targetFar, 0.05);
      fog.near = THREE.MathUtils.lerp(fog.near, targetNear, 0.05);
    }
    state.scene.background = state.scene.fog ? (state.scene.fog as THREE.Fog).color : fogColor;
    
    if (lightningRef.current) {
      lightningRef.current.intensity = simState.lightning * 10;
      if (simState.lightning > 0.8) {
        lightningRef.current.position.set((Math.random() - 0.5) * 100, 50, (Math.random() - 0.5) * 100);
      }
    }
  });

  return (
    <>
      <Sky ref={skyRef} distance={450000} sunPosition={[0, 1, 0]} inclination={0} azimuth={0.25} />
      <ambientLight intensity={0.2} />
      <directionalLight 
        ref={sunRef} 
        castShadow 
        color="#ffeedd" 
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
      />
      <directionalLight 
        ref={underwaterLightRef}
        color="#88ccff"
        position={[0, 50, 0]}
      />
      <pointLight ref={lightningRef} color="#ffffff" distance={200} decay={2} />
      <Stars radius={100} depth={50} count={3000} factor={4} saturation={0} fade speed={1} />
      <fog attach="fog" args={['#051a24', 10, 150]} />
    </>
  );
}

function WeatherSystem() {
  useFrame((state, delta) => {
    const time = state.clock.getElapsedTime();
    simState.time = time;
    
    const windAngle = noise2D(time * 0.005, 0) * Math.PI * 2;
    simState.wind.set(Math.cos(windAngle), Math.sin(windAngle));
    
    simState.windOffset.x += simState.wind.x * delta * (0.5 + simState.weatherIntensity);
    simState.windOffset.y += simState.wind.y * delta * (0.5 + simState.weatherIntensity);
    simState.currentOffset.x += simState.current.x * delta * 0.5;
    simState.currentOffset.y += simState.current.y * delta * 0.5;
    
    simState.tide = Math.sin(time * 0.02) * 2.0;
    
    const weatherNoise = noise2D(time * 0.002, 100);
    if (weatherNoise > 0.6) {
      simState.weatherType = 'storm';
      simState.weatherIntensity = THREE.MathUtils.lerp(simState.weatherIntensity, 1, delta * 0.1);
    } else if (weatherNoise > 0.2) {
      simState.weatherType = 'rain';
      simState.weatherIntensity = THREE.MathUtils.lerp(simState.weatherIntensity, 0.5, delta * 0.1);
    } else if (weatherNoise < -0.4) {
      simState.weatherType = 'fog';
      simState.weatherIntensity = THREE.MathUtils.lerp(simState.weatherIntensity, 0.2, delta * 0.1);
    } else {
      simState.weatherType = 'clear';
      simState.weatherIntensity = THREE.MathUtils.lerp(simState.weatherIntensity, 0, delta * 0.1);
    }
    
    if (simState.weatherType === 'storm' && Math.random() < 0.01) {
      simState.lightning = 1.0;
    } else {
      simState.lightning = Math.max(0, simState.lightning - delta * 2);
    }
    
    if (simState.weatherType === 'clear' && simState.time % 120 > 30 && simState.time % 120 < 90) {
      simState.player.temp = THREE.MathUtils.lerp(simState.player.temp, 39, delta * 0.01);
      simState.player.hydration -= delta * 0.5;
    } else if (simState.weatherType === 'storm' || simState.weatherType === 'rain') {
      simState.player.temp = THREE.MathUtils.lerp(simState.player.temp, 35, delta * 0.02);
      simState.player.hydration += delta * 0.2; 
    } else {
      simState.player.temp = THREE.MathUtils.lerp(simState.player.temp, 37, delta * 0.01);
      simState.player.hydration -= delta * 0.1;
    }
    simState.player.hydration = Math.max(0, Math.min(100, simState.player.hydration));
  });
  return null;
}

function MarineLife({ raftRef }: { raftRef: React.RefObject<THREE.Group | null> }) {
  const tunaCount = 30;
  const whaleCount = 3;
  
  const tunaGeom = useMemo(() => {
    const shape = new THREE.Shape();
    shape.moveTo(0, 0); // nose
    shape.quadraticCurveTo(0.5, 0.3, 1.5, 0.1); // top back
    shape.lineTo(2.0, 0.4); // top tail
    shape.lineTo(1.8, 0); // tail center
    shape.lineTo(2.0, -0.4); // bottom tail
    shape.lineTo(1.5, -0.1); // bottom back
    shape.quadraticCurveTo(0.5, -0.3, 0, 0); // bottom belly
    const g = new THREE.ExtrudeGeometry(shape, { depth: 0.15, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.05, bevelThickness: 0.05 });
    g.center();
    g.rotateY(-Math.PI / 2); // face forward (-Z)
    
    // Add phase attribute for swimming animation
    const phases = new Float32Array(tunaCount);
    for(let i=0; i<tunaCount; i++) phases[i] = Math.random() * Math.PI * 2;
    g.setAttribute('phase', new THREE.InstancedBufferAttribute(phases, 1));
    return g;
  }, []);
  
  const tunaMat = useMemo(() => {
    const m = new THREE.MeshStandardMaterial({ color: '#88aacc', roughness: 0.3, metalness: 0.8 });
    m.onBeforeCompile = (shader) => {
      shader.uniforms.time = { value: 0 };
      m.userData.shader = shader;
      shader.vertexShader = `
        uniform float time;
        attribute float phase;
        ${shader.vertexShader}
      `.replace(
        `#include <begin_vertex>`,
        `
        #include <begin_vertex>
        float wiggle = sin(time * 10.0 + position.z * 2.0 + phase) * 0.1 * max(0.0, position.z + 1.0);
        transformed.x += wiggle;
        `
      );
    };
    return m;
  }, []);
  
  const whaleGeom = useMemo(() => {
    const shape = new THREE.Shape();
    shape.moveTo(0, 0); // nose
    shape.quadraticCurveTo(2, 1.5, 6, 0.5); // top back
    shape.lineTo(8, 2); // top tail
    shape.lineTo(7.5, 0); // tail center
    shape.lineTo(8, -2); // bottom tail
    shape.lineTo(6, -0.5); // bottom back
    shape.quadraticCurveTo(2, -1.0, 0, 0); // bottom belly
    const g = new THREE.ExtrudeGeometry(shape, { depth: 1.5, bevelEnabled: true, bevelSegments: 3, steps: 1, bevelSize: 0.5, bevelThickness: 0.5 });
    g.center();
    g.rotateY(-Math.PI / 2);
    
    const phases = new Float32Array(whaleCount);
    for(let i=0; i<whaleCount; i++) phases[i] = Math.random() * Math.PI * 2;
    g.setAttribute('phase', new THREE.InstancedBufferAttribute(phases, 1));
    return g;
  }, []);
  
  const whaleMat = useMemo(() => {
    const m = new THREE.MeshStandardMaterial({ color: '#112233', roughness: 0.8 });
    m.onBeforeCompile = (shader) => {
      shader.uniforms.time = { value: 0 };
      m.userData.shader = shader;
      shader.vertexShader = `
        uniform float time;
        attribute float phase;
        ${shader.vertexShader}
      `.replace(
        `#include <begin_vertex>`,
        `
        #include <begin_vertex>
        float wiggle = sin(time * 2.0 + position.z * 0.5 + phase) * 0.5 * max(0.0, position.z + 2.0);
        transformed.x += wiggle;
        `
      );
    };
    return m;
  }, []);
  
  const tunaMeshRef = useRef<THREE.InstancedMesh>(null);
  const whaleMeshRef = useRef<THREE.InstancedMesh>(null);
  
  const tunaData = useMemo(() => {
    return Array.from({ length: tunaCount }).map(() => ({
      position: new THREE.Vector3((Math.random() - 0.5) * 40, -1 - Math.random() * 5, (Math.random() - 0.5) * 40),
      velocity: new THREE.Vector3((Math.random() - 0.5), 0, (Math.random() - 0.5)).normalize().multiplyScalar(3),
      phase: Math.random() * Math.PI * 2,
    }));
  }, []);

  const whaleData = useMemo(() => {
    return Array.from({ length: whaleCount }).map(() => ({
      position: new THREE.Vector3((Math.random() - 0.5) * 150, -5 - Math.random() * 10, (Math.random() - 0.5) * 150),
      velocity: new THREE.Vector3((Math.random() - 0.5), 0, (Math.random() - 0.5)).normalize().multiplyScalar(1.5),
      phase: Math.random() * Math.PI * 2,
    }));
  }, []);

  const dummy = useMemo(() => new THREE.Object3D(), []);

  useFrame((state, delta) => {
    if (!raftRef.current) return;
    const raftPos = raftRef.current.position;
    
    if (tunaMat.userData.shader) tunaMat.userData.shader.uniforms.time.value = state.clock.getElapsedTime();
    if (whaleMat.userData.shader) whaleMat.userData.shader.uniforms.time.value = state.clock.getElapsedTime();
    
    if (tunaMeshRef.current) {
      tunaData.forEach((fish, i) => {
        fish.position.addScaledVector(fish.velocity, delta);
        fish.position.y += Math.sin(state.clock.elapsedTime * 3 + fish.phase) * delta * 0.5;
        
        if (fish.position.distanceTo(raftPos) > 50) {
          fish.position.copy(raftPos).add(new THREE.Vector3((Math.random() - 0.5) * 40, -1 - Math.random() * 5, (Math.random() - 0.5) * 40));
        }
        
        const waterY = getWaterHeight(fish.position.x, fish.position.z, state.clock.elapsedTime);
        if (fish.position.y > waterY - 0.5) {
          fish.position.y = waterY - 0.5;
          fish.velocity.y -= delta;
        }
        
        dummy.position.copy(fish.position);
        const target = fish.position.clone().add(fish.velocity);
        dummy.lookAt(target);
        dummy.updateMatrix();
        tunaMeshRef.current!.setMatrixAt(i, dummy.matrix);
      });
      tunaMeshRef.current.instanceMatrix.needsUpdate = true;
    }

    if (whaleMeshRef.current) {
      whaleData.forEach((whale, i) => {
        whale.position.addScaledVector(whale.velocity, delta);
        whale.position.y += Math.sin(state.clock.elapsedTime * 0.5 + whale.phase) * delta * 2.0;
        
        if (whale.position.distanceTo(raftPos) > 200) {
          whale.position.copy(raftPos).add(new THREE.Vector3((Math.random() - 0.5) * 150, -5 - Math.random() * 10, (Math.random() - 0.5) * 150));
        }
        
        const waterY = getWaterHeight(whale.position.x, whale.position.z, state.clock.elapsedTime);
        if (whale.position.y > waterY - 1.0) {
          whale.position.y = waterY - 1.0;
          whale.velocity.y -= delta;
        }
        
        dummy.position.copy(whale.position);
        const target = whale.position.clone().add(whale.velocity);
        dummy.lookAt(target);
        dummy.updateMatrix();
        whaleMeshRef.current!.setMatrixAt(i, dummy.matrix);
      });
      whaleMeshRef.current.instanceMatrix.needsUpdate = true;
    }
  });

  return (
    <>
      <instancedMesh ref={tunaMeshRef} args={[tunaGeom, tunaMat, tunaCount]} castShadow receiveShadow />
      <instancedMesh ref={whaleMeshRef} args={[whaleGeom, whaleMat, whaleCount]} castShadow receiveShadow />
    </>
  );
}

function KelpForest() {
  const count = 300;
  
  const geom = useMemo(() => {
    const g = new THREE.CylinderGeometry(0.05, 0.05, 10, 5, 10);
    g.translate(0, 5, 0); // base at 0
    
    const phases = new Float32Array(count);
    for(let i=0; i<count; i++) phases[i] = Math.random() * Math.PI * 2;
    g.setAttribute('phase', new THREE.InstancedBufferAttribute(phases, 1));
    return g;
  }, []);
  
  const mat = useMemo(() => {
    const m = new THREE.MeshStandardMaterial({ color: '#2a4f2a', roughness: 0.8, side: THREE.DoubleSide });
    m.onBeforeCompile = (shader) => {
      shader.uniforms.time = { value: 0 };
      m.userData.shader = shader;
      shader.vertexShader = `
        uniform float time;
        attribute float phase;
        ${shader.vertexShader}
      `.replace(
        `#include <begin_vertex>`,
        `
        #include <begin_vertex>
        float swayX = sin(time * 0.5 + phase) * position.y * 0.1;
        float swayZ = cos(time * 0.3 + phase) * position.y * 0.1;
        transformed.x += swayX;
        transformed.z += swayZ;
        `
      );
    };
    return m;
  }, []);

  const instancedMeshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const [initialized, setInitialized] = useState(false);

  useFrame((state) => {
    if (mat.userData.shader) {
      mat.userData.shader.uniforms.time.value = state.clock.getElapsedTime();
    }
    
    // Initialize positions once
    if (!initialized && instancedMeshRef.current) {
      for (let i = 0; i < count; i++) {
        const x = (Math.random() - 0.5) * 200;
        const z = (Math.random() - 0.5) * 200;
        const y = getOceanFloorHeight(x, z);
        
        // Only place kelp in relatively shallow areas
        if (y > -30) {
          dummy.position.set(x, y, z);
          dummy.scale.set(1, 0.5 + Math.random() * 1.5, 1);
          dummy.updateMatrix();
          instancedMeshRef.current.setMatrixAt(i, dummy.matrix);
        } else {
          dummy.position.set(0, -1000, 0); // hide
          dummy.updateMatrix();
          instancedMeshRef.current.setMatrixAt(i, dummy.matrix);
        }
      }
      instancedMeshRef.current.instanceMatrix.needsUpdate = true;
      setInitialized(true);
    }
  });

  return <instancedMesh ref={instancedMeshRef} args={[geom, mat, count]} receiveShadow castShadow />;
}

function Weather() {
  const count = 5000;
  const geom = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 100;
      positions[i * 3 + 1] = Math.random() * 50;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 100;
      velocities[i] = 0.5 + Math.random() * 0.5;
    }
    g.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    g.setAttribute('velocity', new THREE.BufferAttribute(velocities, 1));
    return g;
  }, [count]);

  const mat = useMemo(() => new THREE.PointsMaterial({
    color: '#aaccff',
    size: 0.1,
    transparent: true,
    opacity: 0,
  }), []);

  const pointsRef = useRef<THREE.Points>(null);

  useFrame((state, delta) => {
    if (!pointsRef.current) return;
    const pos = geom.attributes.position;
    const vel = geom.attributes.velocity;
    
    const camPos = state.camera.position;
    
    const isRaining = simState.weatherType === 'rain' || simState.weatherType === 'storm';
    const targetOpacity = isRaining ? simState.weatherIntensity : 0;
    mat.opacity = THREE.MathUtils.lerp(mat.opacity, targetOpacity * 0.5, delta);
    
    if (mat.opacity > 0.01) {
      for (let i = 0; i < count; i++) {
        let y = pos.getY(i);
        y -= vel.getX(i) * delta * 30; 
        
        let x = pos.getX(i);
        let z = pos.getZ(i);
        x += simState.wind.x * delta * 15;
        z += simState.wind.y * delta * 15;
        
        if (y < -5) {
          y = camPos.y + 40 + Math.random() * 20;
        }
        
        const dx = x - camPos.x;
        const dz = z - camPos.z;
        
        if (dx > 50) x -= 100;
        if (dx < -50) x += 100;
        if (dz > 50) z -= 100;
        if (dz < -50) z += 100;
        
        pos.setX(i, x);
        pos.setY(i, y);
        pos.setZ(i, z);
      }
      pos.needsUpdate = true;
    }
  });

  return <points ref={pointsRef} geometry={geom} material={mat} />;
}

function ProceduralClouds() {
  const clusterCount = 20;
  const spheresPerCluster = 15;
  const totalSpheres = clusterCount * spheresPerCluster;
  
  const cloudGeom = useMemo(() => new THREE.SphereGeometry(1, 16, 16), []);
  const cloudMat = useMemo(() => new THREE.MeshStandardMaterial({ 
    color: 0xffffff, 
    transparent: true, 
    opacity: 0.4, 
    roughness: 1,
    depthWrite: false
  }), []);
  const instancedMeshRef = useRef<THREE.InstancedMesh>(null);
  
  const cloudData = useMemo(() => {
    const data = [];
    for (let c = 0; c < clusterCount; c++) {
      const clusterPos = new THREE.Vector3((Math.random() - 0.5) * 400, 60 + Math.random() * 20, (Math.random() - 0.5) * 400);
      const clusterScale = 10 + Math.random() * 10;
      
      for (let s = 0; s < spheresPerCluster; s++) {
        const offset = new THREE.Vector3((Math.random() - 0.5) * 2, (Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 2).multiplyScalar(clusterScale);
        const scale = new THREE.Vector3(1 + Math.random(), 0.8 + Math.random() * 0.4, 1 + Math.random()).multiplyScalar(clusterScale * (0.5 + Math.random() * 0.5));
        
        data.push({
          clusterId: c,
          clusterPos: clusterPos.clone(),
          localPos: offset,
          scale: scale
        });
      }
    }
    return data;
  }, []);

  const dummy = useMemo(() => new THREE.Object3D(), []);

  useFrame((state, delta) => {
    if (!instancedMeshRef.current) return;
    
    const camPos = state.camera.position;
    const clusterCenters = new Map();
    
    cloudData.forEach(d => {
      if (!clusterCenters.has(d.clusterId)) {
        d.clusterPos.x += simState.wind.x * delta * 5;
        d.clusterPos.z += simState.wind.y * delta * 5;
        
        if (d.clusterPos.x > camPos.x + 200) d.clusterPos.x -= 400;
        if (d.clusterPos.x < camPos.x - 200) d.clusterPos.x += 400;
        if (d.clusterPos.z > camPos.z + 200) d.clusterPos.z -= 400;
        if (d.clusterPos.z < camPos.z - 200) d.clusterPos.z += 400;
        
        clusterCenters.set(d.clusterId, d.clusterPos);
      }
    });

    cloudData.forEach((cloud, i) => {
      const center = clusterCenters.get(cloud.clusterId);
      dummy.position.copy(center).add(cloud.localPos);
      dummy.scale.copy(cloud.scale);
      dummy.updateMatrix();
      instancedMeshRef.current!.setMatrixAt(i, dummy.matrix);
    });
    instancedMeshRef.current.instanceMatrix.needsUpdate = true;
    
    const time = state.clock.getElapsedTime();
    const dayDuration = 3600;
    const timeOffset = (8 / 24) * dayDuration;
    const dayCycle = ((time + timeOffset) / dayDuration) * Math.PI * 2;
    const sunY = Math.sin(dayCycle) * 100 + 50;
    const sunHeight = Math.max(0, sunY / 150);
    
    let targetColor = new THREE.Color('#ffffff');
    if (sunHeight < 0.2) {
      targetColor.lerp(new THREE.Color('#ffaa88'), 1 - (sunHeight / 0.2));
    }
    if (sunHeight <= 0) {
      targetColor.copy(new THREE.Color('#223344'));
    }
    
    if (simState.weatherType === 'storm') {
      targetColor.lerp(new THREE.Color('#444455'), 0.8);
    } else if (simState.weatherType === 'rain') {
      targetColor.lerp(new THREE.Color('#888899'), 0.5);
    }
    
    cloudMat.color.lerp(targetColor, delta * 0.5);
    
    const targetOpacity = simState.weatherType === 'fog' ? 0.2 : 0.6;
    cloudMat.opacity = THREE.MathUtils.lerp(cloudMat.opacity, targetOpacity, delta * 0.5);
  });

  return <instancedMesh ref={instancedMeshRef} args={[cloudGeom, cloudMat, totalSpheres]} />;
}

function RandomEvents() {
  const [event, setEvent] = useState<{type: string, pos: THREE.Vector3, active: boolean}>({ type: 'none', pos: new THREE.Vector3(), active: false });
  
  useFrame((state, delta) => {
    if (!event.active && Math.random() < 0.0005) { // Rare chance
      const types = ['ship', 'meteor', 'cruise', 'balloon', 'plane'];
      const type = types[Math.floor(Math.random() * types.length)];
      const angle = Math.random() * Math.PI * 2;
      const dist = 100 + Math.random() * 50;
      let yPos = 0;
      if (type === 'meteor') yPos = 100;
      if (type === 'balloon') yPos = 30 + Math.random() * 20;
      if (type === 'plane') yPos = 80;
      
      const pos = new THREE.Vector3(
        state.camera.position.x + Math.cos(angle) * dist,
        yPos,
        state.camera.position.z + Math.sin(angle) * dist
      );
      setEvent({ type, pos, active: true });
    }
    
    if (event.active) {
      if (event.type === 'meteor') {
        event.pos.y -= delta * 50;
        event.pos.x += delta * 20;
        if (event.pos.y < 0) setEvent(e => ({...e, active: false}));
      } else if (event.type === 'ship' || event.type === 'cruise') {
        event.pos.x += delta * 2;
        if (event.pos.distanceTo(state.camera.position) > 300) {
          setEvent(e => ({...e, active: false}));
        }
      } else if (event.type === 'balloon') {
        event.pos.x += simState.wind.x * delta * 2;
        event.pos.z += simState.wind.y * delta * 2;
        if (event.pos.distanceTo(state.camera.position) > 300) {
          setEvent(e => ({...e, active: false}));
        }
      } else if (event.type === 'plane') {
        event.pos.x += delta * 40;
        event.pos.y -= delta * 15; // Crashing down
        if (event.pos.y < 0) setEvent(e => ({...e, active: false}));
      }
    }
  });
  
  if (!event.active) return null;
  
  if (event.type === 'meteor') {
    return (
      <mesh position={event.pos}>
        <sphereGeometry args={[1, 8, 8]} />
        <meshBasicMaterial color="#ffaa00" />
        <pointLight color="#ffaa00" intensity={10} distance={50} />
      </mesh>
    );
  }
  
  if (event.type === 'ship') {
    return (
      <mesh position={event.pos}>
        <boxGeometry args={[20, 5, 5]} />
        <meshStandardMaterial color="#333333" />
      </mesh>
    );
  }

  if (event.type === 'cruise') {
    return (
      <group position={event.pos}>
        <mesh position={[0, 2.5, 0]}>
          <boxGeometry args={[40, 5, 8]} />
          <meshStandardMaterial color="#ffffff" />
        </mesh>
        <mesh position={[0, 7.5, 0]}>
          <boxGeometry args={[30, 5, 6]} />
          <meshStandardMaterial color="#eeeeee" />
        </mesh>
      </group>
    );
  }

  if (event.type === 'balloon') {
    return (
      <group position={event.pos}>
        <mesh position={[0, 5, 0]}>
          <sphereGeometry args={[3, 16, 16]} />
          <meshStandardMaterial color="#ff3333" />
        </mesh>
        <mesh position={[0, 0, 0]}>
          <boxGeometry args={[1, 1, 1]} />
          <meshStandardMaterial color="#8b4513" />
        </mesh>
      </group>
    );
  }

  if (event.type === 'plane') {
    return (
      <group position={event.pos} rotation={[0, 0, -Math.PI / 8]}>
        <mesh>
          <cylinderGeometry args={[1, 1, 10, 8]} />
          <meshStandardMaterial color="#dddddd" />
        </mesh>
        <mesh position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <boxGeometry args={[2, 0.2, 12]} />
          <meshStandardMaterial color="#cccccc" />
        </mesh>
        <mesh position={[4, 1, 0]}>
          <boxGeometry args={[1, 2, 0.2]} />
          <meshStandardMaterial color="#cccccc" />
        </mesh>
      </group>
    );
  }
  
  return null;
}

export default function OceanWorld() {
  const raftRef = useRef<THREE.Group>(null);
  const [uiState, setUiState] = useState({
    temp: 37,
    hydration: 100,
    weather: 'clear',
    camera: 'survivor'
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setUiState({
        temp: Math.round(simState.player.temp * 10) / 10,
        hydration: Math.round(simState.player.hydration),
        weather: simState.weatherType,
        camera: simState.cameraMode
      });
    }, 500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-screen bg-black overflow-hidden relative">
      <Canvas shadows camera={{ position: [0, 5, 10], fov: 60 }}>
        <WeatherSystem />
        <ProceduralClouds />
        <RandomEvents />
        <Environment />
        <OceanFloor />
        <KelpForest />
        <Ocean />
        <Raft raftRef={raftRef} />
        <MarineLife raftRef={raftRef} />
        <Weather />
        <CameraController raftRef={raftRef} />
      </Canvas>
      
      {/* Minimal UI Overlay */}
      <div className="absolute top-8 left-8 text-white/50 font-serif tracking-widest text-sm pointer-events-none select-none">
        A D R I F T
      </div>
      
      <div className="absolute top-8 right-8 flex flex-col items-end gap-2 text-white/70 font-mono text-xs">
        <div className="bg-black/50 px-3 py-1 rounded border border-white/10">
          TEMP: {uiState.temp}°C
        </div>
        <div className="bg-black/50 px-3 py-1 rounded border border-white/10">
          HYDRATION: {uiState.hydration}%
        </div>
        <div className="bg-black/50 px-3 py-1 rounded border border-white/10 uppercase">
          WEATHER: {uiState.weather}
        </div>
      </div>

      <div className="absolute bottom-8 left-8 flex gap-2">
        {['raft', 'survivor', 'bird', 'fish'].map((mode) => (
          <button
            key={mode}
            onClick={() => { 
              simState.cameraMode = mode; 
              if (mode === 'bird' && raftRef.current) {
                simState.bird.pos.copy(raftRef.current.position).add(new THREE.Vector3(0, 30, 0));
                simState.bird.speed = 0;
              } else if (mode === 'survivor' && raftRef.current) {
                simState.survivor.pos.copy(raftRef.current.position).add(new THREE.Vector3(0, 2, 0));
              } else if (mode === 'fish' && raftRef.current) {
                simState.fish.pos.copy(raftRef.current.position).add(new THREE.Vector3(0, -5, 5));
                simState.fish.speed = 0;
              }
              setUiState(s => ({...s, camera: mode})) 
            }}
            className={`px-4 py-2 text-xs font-mono uppercase rounded border transition-colors ${
              uiState.camera === mode 
                ? 'bg-white/20 border-white/50 text-white' 
                : 'bg-black/50 border-white/10 text-white/50 hover:bg-white/10'
            }`}
          >
            {mode}
          </button>
        ))}
      </div>

      <div className="absolute bottom-8 right-8 flex flex-col items-end gap-1 text-white/30 font-sans text-xs pointer-events-none select-none max-w-xs text-right">
        {uiState.camera === 'raft' && <span>WASD: Steer & Sail | QE: Sail Angle | Mouse: Look</span>}
        {uiState.camera === 'survivor' && <span>WASD: Move | Mouse: Look</span>}
        {uiState.camera === 'bird' && <span>W/S: Throttle | A/D: Roll | Mouse: Look (Hover)</span>}
        {uiState.camera === 'fish' && <span>W/S: Swim | Mouse: Steer</span>}
        <span className="mt-2">The ocean provides. The ocean takes.</span>
      </div>
    </div>
  );
}
