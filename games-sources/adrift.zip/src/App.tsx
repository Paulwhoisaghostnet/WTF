/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import OceanWorld from './components/OceanWorld';

export default function App() {
  return <OceanWorld />;
}
