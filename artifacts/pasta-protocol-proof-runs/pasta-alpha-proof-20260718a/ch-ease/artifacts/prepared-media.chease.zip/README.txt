CH-EASE portable archive

Open package.chease.json in any Pasta Protocol publisher. Media bytes are in media/. Pin them to IPFS and replace media/ references with ipfs:// CIDs before publishing.
