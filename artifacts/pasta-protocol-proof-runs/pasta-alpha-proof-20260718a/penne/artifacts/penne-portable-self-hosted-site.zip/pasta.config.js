window.PASTA_SITE_CONFIG = {
  "app": "penne",
  "label": "Penne",
  "title": "Penne portable Shadownet proof · pasta-alpha-proof-20260718a",
  "description": "Exported from the actual Penne Studio and served from the extracted standalone ZIP without Objkt, Teia, or wtfOS.",
  "contract": "KT1Di38dfxiKXdMyBHUMbA6kYndNXs3Y67gy",
  "tokenId": 0,
  "network": "shadownet"
};
